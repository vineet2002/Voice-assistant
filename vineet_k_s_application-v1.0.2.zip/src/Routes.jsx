import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "pages/Home";
import NotFound from "pages/NotFound";
const RoboWebDesignTwo = React.lazy(() => import("pages/RoboWebDesignTwo"));
const RoboWebDesignFour = React.lazy(() => import("pages/RoboWebDesignFour"));
const RoboWebDesignThree = React.lazy(() => import("pages/RoboWebDesignThree"));
const RoboWebDesign = React.lazy(() => import("pages/RoboWebDesign"));
const RoboWebDesignOne = React.lazy(() => import("pages/RoboWebDesignOne"));
const ProjectRoutes = () => {
  return (
    <React.Suspense fallback={<>Loading...</>}>
      <Router>
        <Routes>
          <Route path="/" element={<RoboWebDesignOne />} />
          <Route path="*" element={<NotFound />} />
          <Route path="/robowebdesign" element={<RoboWebDesign />} />
          <Route path="/robowebdesignthree" element={<RoboWebDesignThree />} />
          <Route path="/robowebdesignfour" element={<RoboWebDesignFour />} />
          <Route path="/robowebdesigntwo" element={<RoboWebDesignTwo />} />
          <Route path="/dhiwise-dashboard" element={<Home />} />
        </Routes>
      </Router>
    </React.Suspense>
  );
};
export default ProjectRoutes;
