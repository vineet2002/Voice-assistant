import React from "react";

import { Img, Text, Button } from "components";
import { useNavigate } from "react-router-dom";

const RoboWebDesignOnePage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div className="bg-gradient  flex flex-col font-inter items-center justify-start mx-auto p-[34px] sm:px-5 w-full">
        <div className="flex md:flex-col flex-row md:gap-10 items-start justify-between max-w-[1195px] mb-[89px] mx-auto md:px-5 w-full">
          <div className="flex md:flex-1 flex-col md:gap-10 gap-[142px] justify-start mb-[87px] w-auto md:w-full">
            <div className="flex flex-row gap-[7px] items-center justify-start w-[16%] md:w-full">
              <Img
                src="images/img_user.svg"
                className="h-10 w-auto"
                alt="user"
              />
              <Text
                className="text-left text-white_A700 w-auto"
                as="h3"
                variant="h3"
              >
                Miri
              </Text>
            </div>
            <div className="flex flex-col font-poppins items-start justify-start md:ml-[0] ml-[13px] w-[98%] md:w-full">
              <Text
                className="text-left text-white_A700 w-auto"
                as="h1"
                variant="h1"
              >
                Life is Easy
              </Text>
              <Text
                className="text-left text-white_A700 w-auto"
                as="h1"
                variant="h1"
              >
                with Miri
              </Text>
              <Text
                className="font-normal mt-[23px] not-italic text-left text-white_A700 w-full"
                as="h5"
                variant="h5"
              >
                <>
                  Miri is a cutting-edge personal voice assistant designed to
                  make your life easier and more efficient. Whether you&#39;re
                  at home or on-the-go, Miri is always ready to assist you and
                  make your day-to-day tasks simpler and more enjoyable. With
                  Miri, you&#39;ll never have to lift a finger again.
                </>
              </Text>
              <Button
                className="common-pointer bg-gradient1  cursor-pointer font-semibold leading-[normal] min-w-[150px] mt-[59px] py-2.5 rounded-[24px] text-center text-lg text-white_A700 w-auto"
                onClick={() => navigate("/robowebdesign")}
              >
                Get Started
              </Button>
            </div>
          </div>
          <Img
            src="images/img_untitled21.png"
            className="md:flex-1 h-[510px] sm:h-auto md:mt-0 mt-[133px] object-cover w-auto md:w-full"
            alt="untitledTwentyOne"
          />
        </div>
      </div>
    </>
  );
};

export default RoboWebDesignOnePage;
