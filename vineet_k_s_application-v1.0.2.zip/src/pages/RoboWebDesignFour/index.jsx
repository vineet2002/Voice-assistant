import React from "react";

import { Img, Text, Line, Button } from "components";
import { useNavigate } from "react-router-dom";

const RoboWebDesignFourPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div className="bg-gradient  flex flex-col font-inter gap-[25px] justify-start mx-auto p-9 sm:px-5 w-full">
        <div className="flex flex-row gap-[11px] items-start justify-start ml-2 md:ml-[0] md:px-5 w-[7%] md:w-full">
          <Img
            src="images/img_user.svg"
            className="h-[35px] w-auto"
            alt="user"
          />
          <Text
            className="text-left text-white_A700 w-auto"
            as="h3"
            variant="h3"
          >
            Miri
          </Text>
        </div>
        <div className="flex flex-col items-center mb-[15px] ml-2 md:ml-[0] mr-[188px] sm:pl-5 pl-[163px] md:px-5 w-[85%] md:w-full">
          <div className="flex flex-col items-center justify-start w-full">
            <div className="bg-gradient2  flex flex-col font-inter items-start justify-start p-[31px] sm:px-5 rounded-[15px] w-full">
              <div className="flex flex-col items-start justify-start mb-9 md:ml-[0] ml-[13px] w-[91%] md:w-full">
                <div className="flex md:flex-col flex-row gap-[21px] items-center justify-start w-[83%] md:w-full">
                  <Img
                    src="images/img_user_gray_300.png"
                    className="h-[42px] md:h-auto object-cover w-[42px]"
                    alt="user_One"
                  />
                  <Text
                    className="not-italic text-left text-white_A700 w-auto"
                    as="h4"
                    variant="h4"
                  >
                    What were the major contributions of Moses Harris’s in color
                    theory ?
                  </Text>
                </div>
                <Line className="bg-white_A700_87 h-px md:ml-[0] ml-[90px] mt-[22px] w-[85%]" />
                <div className="flex md:flex-col flex-row gap-6 items-start justify-start mt-[9px] w-full">
                  <Button className="bg-white_A700 flex h-[42px] items-center justify-center mb-[158px] p-[5px] rounded-[50%] w-[42px]">
                    <Img
                      src="images/img_group3.svg"
                      className=""
                      alt="groupThree"
                    />
                  </Button>
                  <Text
                    className="sm:flex-1 font-semibold md:mt-0 mt-2.5 text-left text-white_A700 w-[92%] sm:w-full"
                    as="h5"
                    variant="h5"
                  ></Text>
                </div>
              </div>
            </div>
            <Img
              src="images/img_16268270rm373batch501.png"
              className="common-pointer h-[194px] md:h-auto mt-[33px] object-cover w-[194px]"
              onClick={() => navigate("/robowebdesigntwo")}
              alt="16268270rm373ba"
            />
            <Text
              className="font-poppins mt-0.5 text-left text-white_A700_90 w-auto"
              as="h2"
              variant="h2"
            >
              Listening ...
            </Text>
          </div>
        </div>
      </div>
    </>
  );
};

export default RoboWebDesignFourPage;
