import React from "react";

import { Img, Text, Line, Button } from "components";

const RoboWebDesignTwoPage = () => {
  return (
    <>
      <div className="bg-gradient  flex sm:flex-col md:flex-col flex-row font-inter sm:gap-5 md:gap-5 items-start justify-end mx-auto pb-[9px] px-[9px] w-full">
        <Img
          src="images/img_user.svg"
          className="h-[35px] md:mt-0 mt-[37px] w-auto"
          alt="user"
        />
        <Text
          className="ml-2.5 md:ml-[0] md:mt-0 mt-9 text-left text-white_A700 w-auto"
          as="h3"
          variant="h3"
        >
          Miri
        </Text>
        <div className="bg-gradient2  flex flex-col items-start justify-start mb-[41px] md:ml-[0] ml-[78px] md:mt-0 mt-[97px] p-[31px] md:px-5 rounded-[15px] w-[70%] md:w-full">
          <div className="flex flex-col items-start justify-start mb-[3px] md:ml-[0] ml-[13px] w-[87%] md:w-full">
            <div className="flex md:flex-col flex-row gap-[21px] items-center justify-start w-4/5 md:w-full">
              <Img
                src="images/img_user_gray_300.png"
                className="h-[42px] md:h-auto object-cover w-[42px]"
                alt="user_One"
              />
              <Text
                className="not-italic text-left text-white_A700 w-auto"
                as="h4"
                variant="h4"
              >
                Send a message to Joshi that i’ll be late for dinner in WhatsApp
              </Text>
            </div>
            <Line className="bg-white_A700_87 h-px md:ml-[0] ml-[90px] mt-[22px] w-[89%]" />
            <div className="flex sm:flex-col flex-row gap-6 items-center justify-start mt-[9px] w-[72%] md:w-full">
              <Button className="bg-white_A700 flex h-[42px] items-center justify-center p-[5px] rounded-[50%] w-[42px]">
                <Img
                  src="images/img_group3.svg"
                  className=""
                  alt="groupThree"
                />
              </Button>
              <Text
                className="font-normal not-italic text-left text-white_A700 w-auto"
                as="h5"
                variant="h5"
              >
                Sending message to Joshi “ I’ll be late for dinner “ in WhatsApp
              </Text>
            </div>
            <div className="flex flex-col items-center justify-start md:ml-[0] ml-[236px] mt-[13px] shadow-bs w-[51%] md:w-full">
              <div className="h-[458px] relative w-full">
                <Img
                  src="images/img_rectangle2.png"
                  className="h-[458px] m-auto object-cover rounded-[30px] w-full"
                  alt="rectangleTwo"
                />
                <div className="absolute flex flex-col h-max inset-[0] items-start justify-center m-auto w-[99%]">
                  <div className="bg-teal_800 flex flex-row font-inter items-center justify-start p-2.5 rounded-[29px] w-full">
                    <Img
                      src="images/img_arrowleft.svg"
                      className="h-6 ml-[3px] w-6"
                      alt="arrowleft"
                    />
                    <Img
                      src="images/img_profilepic.png"
                      className="h-[39px] md:h-auto ml-0.5 rounded-[50%] w-[39px]"
                      alt="profilepic"
                    />
                    <div className="flex flex-col items-start justify-start ml-[7px] w-auto">
                      <Text
                        className="font-semibold text-left text-white_A700 w-auto"
                        as="h5"
                        variant="h5"
                      >
                        Joshi
                      </Text>
                      <Text
                        className="text-left text-white_A700 w-auto"
                        variant="body1"
                      >
                        online
                      </Text>
                    </div>
                    <Img
                      src="images/img_call.svg"
                      className="h-[25px] ml-[126px] w-[25px]"
                      alt="call"
                    />
                    <Img
                      src="images/img_videocamera.svg"
                      className="h-[30px] ml-3 w-[29px]"
                      alt="videocamera"
                    />
                    <Img
                      src="images/img_overflowmenu.svg"
                      className="h-[22px] ml-3 w-[22px]"
                      alt="overflowmenu"
                    />
                  </div>
                  <Text
                    className="bg-light_blue_50 font-roboto h-[19px] justify-center md:ml-[0] ml-[166px] mt-[7px] not-italic px-[9px] py-[3px] rounded-[5px] text-black_900 text-left w-[45px]"
                    variant="body2"
                  >
                    Today
                  </Text>
                  <div
                    className="bg-cover bg-no-repeat flex flex-col font-roboto h-[31px] items-end justify-start md:ml-[0] ml-[202px] mt-[26px] p-1 w-auto md:w-full"
                    style={{ backgroundImage: "url('images/img_group4.svg')" }}
                  >
                    <Text
                      className="font-normal not-italic text-black_900 text-left w-auto"
                      as="h5"
                      variant="h5"
                    >
                      I’ll be late for dinner
                    </Text>
                  </div>
                  <div className="flex flex-row font-inter gap-2 items-center justify-between md:ml-[0] ml-[5px] mt-[246px] w-[98%] md:w-full">
                    <div className="bg-white_A700_dd flex flex-row items-start justify-start p-3 rounded-[24px] w-auto">
                      <Img
                        src="images/img_menu.svg"
                        className="h-6 w-6"
                        alt="menu"
                      />
                      <Text
                        className="ml-2 mt-[7px] not-italic text-gray_400 text-left w-auto"
                        as="h6"
                        variant="h6"
                      >
                        Type a message
                      </Text>
                      <Img
                        src="images/img_antdesignpape.svg"
                        className="h-6 ml-[92px] w-6"
                        alt="antdesignpape"
                      />
                      <Img
                        src="images/img_camera.svg"
                        className="h-[22px] ml-[9px] mt-[3px] w-[22px]"
                        alt="camera"
                      />
                    </div>
                    <Button className="bg-teal_600 flex h-[49px] items-center justify-center p-[13px] rounded-[24px] w-[49px]">
                      <Img
                        src="images/img_microphone.svg"
                        className=""
                        alt="microphone"
                      />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col font-poppins md:ml-[0] ml-[22px] md:px-5 relative w-[15%] md:w-full">
          <Img
            src="images/img_16268270rm373batch501.png"
            className="h-[194px] mx-auto object-cover w-[194px]"
            alt="16268270rm373ba"
          />
          <Text
            className="ml-auto mr-2.5 mt-[-9.15px] text-left text-white_A700_90 w-auto z-[1]"
            as="h3"
            variant="h3"
          >
            Listening ...
          </Text>
        </div>
      </div>
    </>
  );
};

export default RoboWebDesignTwoPage;
