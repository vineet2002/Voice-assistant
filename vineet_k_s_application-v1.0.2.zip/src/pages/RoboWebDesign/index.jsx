import React from "react";

import { Img, Text } from "components";
import { useNavigate } from "react-router-dom";

const RoboWebDesignPage = () => {
  const navigate = useNavigate();

  return (
    <>
      <div className="bg-gradient  flex flex-col items-start justify-start mx-auto p-[47px] md:px-10 sm:px-5 w-full">
        <div className="flex flex-col gap-1.5 justify-start mb-[95px] md:ml-[0] ml-[22px] w-[68%] md:w-full">
          <div className="flex md:flex-col flex-row font-inter md:gap-5 items-center justify-start w-full">
            <Img
              src="images/img_user.svg"
              className="h-[50px] w-auto"
              alt="user"
            />
            <Text
              className="ml-2.5 md:ml-[0] text-left text-white_A700 w-auto"
              as="h3"
              variant="h3"
            >
              Miri
            </Text>
            <Img
              src="images/img_16268270rm373batch501.png"
              className="sm:flex-1 h-[478px] md:h-auto md:ml-[0] ml-[280px] md:mt-0 mt-[42px] object-cover w-[478px] sm:w-full"
              alt="16268270rm373ba"
            />
          </div>
          <Text
            className="common-pointer font-poppins md:ml-[0] ml-[508px] text-left text-white_A700_90 w-auto"
            as="h1"
            variant="h1"
            onClick={() => navigate("/robowebdesignthree")}
          >
            Speak !
          </Text>
        </div>
      </div>
    </>
  );
};

export default RoboWebDesignPage;
