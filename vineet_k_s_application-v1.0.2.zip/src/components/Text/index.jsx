import React from "react";

const variantClasses = {
  h1: "font-semibold md:text-5xl sm:text-[42px] text-[56px]",
  h2: "font-semibold md:text-3xl sm:text-[28px] text-[32px]",
  h3: "font-semibold sm:text-2xl md:text-[26px] text-[28px]",
  h4: "font-normal text-lg",
  h5: "text-base",
  h6: "font-normal text-[13px]",
  body1: "font-light text-xs",
  body2: "font-normal text-[10px]",
};

const Text = ({ children, className, variant, as, ...restProps }) => {
  const Component = as || "span";
  return (
    <Component
      className={`${className} ${variant && variantClasses[variant]}`}
      {...restProps}
    >
      {children}
    </Component>
  );
};

export { Text };
