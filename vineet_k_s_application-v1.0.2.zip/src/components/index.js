import { Img } from "./Img";
import { Text } from "./Text";
import { Button } from "./Button";
import { Line } from "./Line";
export { Img, Text, Button, Line };
